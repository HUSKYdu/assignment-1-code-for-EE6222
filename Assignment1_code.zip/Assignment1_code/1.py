import matplotlib.pyplot as plt
import matplotlib.image as mpimg
import numpy as np
'''
This is code for EE6222 assignment
student name:DU ZHENYUAN
Matirc No.:G2103702E
in this code, I achieved three methods which can tranform image to binary image:
1 Threshold: give a certain number, if a pixel value bigger than the threshold, set it to 255,if smaller, set to 0
2 Mean_Threshold: will calculate the average gray-level of whole image, and the average number will be used as threshold
3 OTSU: without using existing packages, OTSU is implemented from the bottom
further more, I achieved two thining algorithm:
1 Two_Step_Thining_Algorithm
2 Medial_Axis_Transformation
The specific usage of all algorithms has been written in main. 
If want to get all the data and graphical results in the report, you can run this file directly
'''
#read image, and save as img1 to img6
img1= mpimg.imread('./imges/img1.bmp')
img3= mpimg.imread('./imges/img3.bmp')
img4= mpimg.imread('./imges/img4.bmp')
img5= mpimg.imread('./imges/img5.bmp')
img6= mpimg.imread('./imges/img6.bmp')
plt.figure(figsize=(15,5))
plt.subplot(1,5,1)
plt.imshow(img1)
plt.subplot(1,5,2)
plt.imshow(img3)
plt.subplot(1,5,3)
plt.imshow(img4)
plt.subplot(1,5,4)
plt.imshow(img5)
plt.subplot(1,5,5)
plt.imshow(img6)
plt.tight_layout()
plt.savefig('Original image.svg', type='svg')
plt.show()
def Threshold(image_original,threshold):
    #copy image_original to a new variable
    image=image_original.copy()
    #return lens of row and column
    linelen=len(image)
    rowlen=len(image[0])



    for i in range(0,linelen):
        for j in range(0,rowlen):
            #if value of pixel bigger than threshold, set to 255
            #if smaller, set to 0
            if image[i][j]<=threshold:
                image[i][j]=0
            if image[i][j]>threshold:
                image[i][j] = 255
    #return binary image
    return image
def Mean_Threshold(image1):
    #get copy of new image
    image=image1.copy()
    #get shape of image
    linelen = len(image)
    rowlen = len(image[0])

    #a temporary variable responsible for storing the sum of all pixel values
    sum_pixel=0


    #get sum of value of pixels
    for i in range(0,linelen):
        for j in range(0,rowlen):
            sum_pixel=sum_pixel+image[i][j]

    #calculate average
    sum_pixel=sum_pixel/(linelen*rowlen)

    #using threshold
    for i in range(0,linelen):
        for j in range(0,rowlen):
            if image[i][j]<=sum_pixel:
                image[i][j]=0
            if image[i][j]>sum_pixel:
                image[i][j] = 255

    #return new binary image and threshold
    return image,sum_pixel
def OTSU(image):

    #get image shape
    linelen = len(image)
    rowlen = len(image[0])

    threshold_list_value = []#used to stage the performance matrics of every gray-level
    threshold_list=[]#used to stage threshold number
    h=0
    while(h<255):
        threshold_list.append(h)#get threshold,we should try every gray level from 0 to 255
        h=h+1


    for i in threshold_list:# try every gray level as threshold
        print('trying threshold:',i)
        num_bg_point = 0#statistic number of point of background
        num_obj_point = 0#statistic number of point of object
        bg_pixel_mean=[]#stage mean of background pixel value
        obj_pixel_mean=[]#stage mean of object pixel value
        bg_empty_warning_flag=1
        '''
        because we will try extremely small threshold such as 1 or 255 as threshold, 
        and it is possible that no pixel value smaller that threshold, and when no pixel belong to obj or 
        bg, we can't get mean number, so I set two flag, when no pixel belong to bg or obj, I will set their
        mean number is 0
        '''
        obj_empty_warning_flag = 1


        #Determine whether the pixel is an object or a background under the threshold
        for j in range(0,linelen):
            for k in range(0,rowlen):
                if image[j][k]<=i:
                    num_obj_point=num_obj_point+1
                    obj_pixel_mean.append(image[j][k])
                    obj_empty_warning_flag=0#if any pixel belong to obj, set flag to 0
                if image[j][k]>i:
                    num_bg_point=num_bg_point+1
                    bg_pixel_mean.append(image[j][k])
                    bg_empty_warning_flag=0#if any pixel belong to bg, set flag to 0


        #get mean value of obj and bg under curtain threshold
        if obj_empty_warning_flag==1:
            obj_pixel_mean=0
        else:
            obj_pixel_mean=np.mean(obj_pixel_mean)

        if bg_empty_warning_flag==1:
            bg_pixel_mean=0
        else:
            bg_pixel_mean = np.mean(bg_pixel_mean)


        #calculate the percentage of bg and obj
        percent_bg_point=num_bg_point/(linelen*rowlen)
        percent_obj_point=num_obj_point/(linelen*rowlen)

        #performance matrics formula
        g=percent_bg_point*percent_obj_point*((bg_pixel_mean-obj_pixel_mean)**2)
        #we believe the biggest g represent best threshold
        threshold_list_value.append(g)
    best_threshold=threshold_list_value.index(max(threshold_list_value))
    k=image.copy()#transfrom image to binary according to best threshold
    for i in range(0,linelen):
        for j in range(0,rowlen):
            if k[i][j]<=best_threshold:
                k[i][j]=0
            else:
                k[i][j]=255
    return best_threshold,k#return best threshold and binary image
def Img_to_Binary(pattern,image):
    if pattern=='threshold':
        threshold,result=Threshold(image)
        return threshold,result
    if pattern=='adaptive_threshold':
        threshold,result=Mean_Threshold(image)
        return threshold,result
    if pattern=='OTSU':
        threshold, result = OTSU(image)
        return threshold, result
def NP(binary_image,i,j):
    #The judgment condition function of algorithm Two step thining is used in the function of algorithm Two step thining
    flag=0
    if binary_image[i-1][j-1]==0:
        flag=flag+1
    if binary_image[i-1][j]==0:
        flag=flag + 1
    if binary_image[i-1][j+1]==0:
        flag=flag + 1
    if binary_image[i][j-1]==0:
        flag=flag + 1
    if binary_image[i][j+1]==0:
        flag=flag + 1
    if binary_image[i+1][j-1]==0:
        flag=flag + 1
    if binary_image[i+1][j]==0:
        flag=flag + 1
    if binary_image[i+1][j+1]==0:
        flag=flag+1
    return flag
def SP(binary_image,i,j):
    # The judgment condition function of algorithm Two step thining is used in the function of algorithm Two step thining
    flag=0
    if binary_image[i-1][j]>binary_image[i-1][j-1]:
        flag=flag+1
    if binary_image[i-1][j-1]>binary_image[i][j-1]:
        flag=flag+1
    if binary_image[i][j-1]>binary_image[i+1][j-1]:
        flag=flag+1
    if binary_image[i+1][j-1]>binary_image[i+1][j]:
        flag=flag+1
    if binary_image[i+1][j]>binary_image[i+1][j+1]:
        flag=flag+1
    if binary_image[i+1][j+1]>binary_image[i][j+1]:
        flag=flag+1
    if binary_image[i][j+1]>binary_image[i-1][j+1]:
        flag=flag+1
    if binary_image[i-1][j+1]>binary_image[i-1][j]:
        flag=flag+1
    return flag
def P246_And_P468(binary_image,i,j):
    # The judgment condition function of algorithm Two step thining is used in the function of algorithm Two step thining
    P246=1
    P468=1
    if binary_image[i-1][j]>1 or binary_image[i][j+1]>1 or binary_image[i+1][j]>1:
        P246=0
    if binary_image[i][j-1] > 1 or binary_image[i][j + 1] > 1 or binary_image[i + 1][j] > 1:
        P468=0
    return P246,P468
def P248_And_P268(binary_image,i,j):
    # The judgment condition function of algorithm Two step thining is used in the function of algorithm Two step thining
    P246=1
    P468=1
    if binary_image[i-1][j]>1 or binary_image[i][j+1]>1 or binary_image[i][j-1]>1:
        P246=0
    if binary_image[i-1][j]>1 or binary_image[i+1][j]>1 or binary_image[i][j-1]>1:
        P468=0
    return P246,P468
def Two_Step_Thining_Algorithm(binary_image1):
    binary_image=binary_image1.copy()
    step1_flag=1#because it has two step and when both of two step don't delete any point, it will stop
    #this two flag is to flag weather this step delete any point
    step2_flag=1
    #get shape of image
    linelen = len(binary_image)
    rowlen = len(binary_image[0])
    while(step1_flag==1 and step2_flag==1):#while step 1 or step 2 still delete point, continue
        step1_flag = 0
        step1_removed_list=[]#stage position of points which should be delete
        for i in range(0,linelen):
            for j in range(0,rowlen):
                if binary_image[i][j]==0:
                    dele_flag=0
                    Np=NP(binary_image, i, j)#get the pixel's Np
                    Sp=SP(binary_image,i,j)#get the pixel's Sp
                    p246,p468=P246_And_P468(binary_image,i,j)#get p246 and p468
                    if Np>=2 and Np<=6 and Sp==1 and p246==0 and p468==0:
                        dele_flag=1
                    if dele_flag==1:
                        step1_removed_list.append([i,j])
                        #binary_image[i][j]=255
                        step1_flag = 1

        s1len=len(step1_removed_list)
        for o in range(0,s1len):#remove point that signed in step 1
            binary_image[step1_removed_list[o][0]][step1_removed_list[o][1]]=255


        #step2
        step2_flag = 0
        step2_removed_list=[]
        for k in range(0,linelen):
            for m in range(0,rowlen):
                if binary_image[k][m]==0:
                    dele_flag=0
                    Np=NP(binary_image, k, m)
                    Sp=SP(binary_image,k,m)
                    p248,p268=P248_And_P268(binary_image,k,m)
                    if Np>=2 and Np<=6 and Sp==1 and p248==0 and p268==0:
                        dele_flag=1
                    if dele_flag==1:
                        step2_removed_list.append([k,m])
                        # binary_image[i][j]=255
                        step2_flag = 1

        s2len = len(step2_removed_list)
        for o in range(0, s2len):
            binary_image[step2_removed_list[o][0]][step2_removed_list[o][1]] = 255


    return binary_image
def Distance_map(binary_image):
    #get distance map or binary image
    linelen = len(binary_image)
    rowlen = len(binary_image[0])
    distance_map=[[0] * (rowlen) for _ in range(linelen)]

    for i in range(0,linelen):
        for j in range(0,rowlen):
            if binary_image[i][j]==0:
                flag=0
                dis = 1
                while(flag!=1):
                    if binary_image[i-dis][j]==255 or binary_image[i+dis][j]==255 or binary_image[i][j-dis]==255 or binary_image[i+1][j+dis]==255:
                        distance_map[i][j]=dis
                        flag=1
                    else:
                        dis=dis+1
    return distance_map
def AV(a):
    if a<0:
        a=-a
    else:
        a=a
    return a
def dis(a,b):
    i1=a[0]
    j1 = a[1]
    i2 = b[0]
    j2 = b[1]

    dis=((i1-i2)**2+(j1-j2)**2)**0.5
    return dis
def Medial_Axis_Transformation(binary_image):
    dis_map=Distance_map(binary_image)
    linelen = len(binary_image)
    rowlen = len(binary_image[0])

    skeleton=dis_map.copy()
    h=0
    #initialize the boundary and region
    boundary = [[0] * (rowlen) for _ in range(linelen)]
    region = [[0] * (rowlen) for _ in range(linelen)]
    region_point = []
    boundary_point = []
    flag2=1
    print('h:',h)
    h=h+1
    for i in range(0,linelen):
        for j in range(0,rowlen):
            if skeleton[i][j]>0:
                flag1=0
                #up, down, right, left, four directs, if any direct
                if skeleton[i+1][j]>0:
                    flag1=flag1+1
                if skeleton[i-1][j]>0:
                    flag1=flag1+1
                if skeleton[i][j+1]>0:
                    flag1=flag1+1
                if skeleton[i][j-1]>0:
                    flag1=flag1+1
                if flag1>1 and flag1<4:
                    boundary_point.append([i,j])
                    boundary[i][j]=255
                if flag1==4:
                    region_point.append([i, j])
                    region[i][j] = 255
    regionlen=len(region_point)
    boundarylen=len(boundary_point)
    skeleton = [[0] * (rowlen) for _ in range(linelen)]
    for i in range(0,regionlen):
        dislist=[]
        for j in range(0,boundarylen):
            dislist.append(dis(region_point[i],boundary_point[j]))
        mindis=min(dislist)
        dislistlen=len(dislist)
        count=0
        for j in range(0,dislistlen):
            if dislist[j]==mindis:
                count=count+1
        if count>1:
            skeleton[region_point[i][0]][region_point[i][1]]=255
            flag2=0
    for i in range(0,linelen):
        for j in range(0,rowlen):
            if skeleton[i][j]==0:
                skeleton[i][j]=255
            else:
                skeleton[i][j] = 0

    return skeleton
def main_function(img1,img3,img4,img5,img6,threshold1,threshold2):

    Treshold1_img1=Threshold(img1,threshold1)
    Treshold1_img3 = Threshold(img3, threshold1)
    Treshold1_img4 = Threshold(img4, threshold1)
    Treshold1_img5 = Threshold(img5, threshold1)
    Treshold1_img6 = Threshold(img6, threshold1)
    Treshold2_img1 = Threshold(img1, threshold2)
    Treshold2_img3 = Threshold(img3, threshold2)
    Treshold2_img4 = Threshold(img4, threshold2)
    Treshold2_img5 = Threshold(img5, threshold2)
    Treshold2_img6 = Threshold(img6, threshold2)
    plt.figure(figsize=(15, 5))
    plt.subplot(2,5,1)
    plt.imshow(Treshold1_img1)
    plt.subplot(2, 5, 2)
    plt.imshow(Treshold1_img3)
    plt.subplot(2, 5, 3)
    plt.imshow(Treshold1_img4)
    plt.subplot(2, 5, 4)
    plt.imshow(Treshold1_img5)
    plt.subplot(2, 5, 5)
    plt.imshow(Treshold1_img6)
    plt.subplot(2, 5, 6)
    plt.imshow(Treshold2_img1)
    plt.subplot(2, 5, 7)
    plt.imshow(Treshold2_img3)
    plt.subplot(2, 5, 8)
    plt.imshow(Treshold2_img4)
    plt.subplot(2,5,9)
    plt.imshow(Treshold2_img5)
    plt.subplot(2, 5, 10)
    plt.imshow(Treshold2_img6)
    plt.tight_layout()
    plt.savefig('Fix_Threshold.svg', type='svg')
    plt.show()

    ############################################################
    mean_threshold=[]
    Mean_threshold_img1,a=Mean_Threshold(img1)
    mean_threshold.append(a)
    Mean_threshold_img3,a= Mean_Threshold(img3)
    mean_threshold.append(a)
    Mean_threshold_img4,a = Mean_Threshold(img4)
    mean_threshold.append(a)
    Mean_threshold_img5 ,a= Mean_Threshold(img5)
    mean_threshold.append(a)
    Mean_threshold_img6,a = Mean_Threshold(img6)
    mean_threshold.append(a)
    plt.figure(figsize=(15, 5))
    plt.subplot(1,5,1)
    plt.imshow(Mean_threshold_img1)
    plt.subplot(1, 5, 2)
    plt.imshow(Mean_threshold_img3)
    plt.subplot(1, 5, 3)
    plt.imshow(Mean_threshold_img4)
    plt.subplot(1, 5, 4)
    plt.imshow(Mean_threshold_img5)
    plt.subplot(1, 5, 5)
    plt.imshow(Mean_threshold_img6)
    plt.tight_layout()
    plt.savefig('Mean_Threshold.svg', type='svg')
    plt.show()
    print('Threshold of every image in method of Mean_Treshold is:')
    print(mean_threshold)
    ###############################################################################
    otsu_threshold=[]
    a,otsu_image1=OTSU(img1)
    otsu_threshold.append(a)
    a, otsu_image3 = OTSU(img3)
    otsu_threshold.append(a)
    a, otsu_image4 = OTSU(img4)
    otsu_threshold.append(a)
    a, otsu_image5 = OTSU(img5)
    otsu_threshold.append(a)
    a, otsu_image6 = OTSU(img6)
    otsu_threshold.append(a)
    plt.subplot(1,5,1)
    plt.imshow(otsu_image1)
    plt.subplot(1, 5, 2)
    plt.imshow(otsu_image3)
    plt.subplot(1, 5, 3)
    plt.imshow(otsu_image4)
    plt.subplot(1, 5, 4)
    plt.imshow(otsu_image5)
    plt.subplot(1, 5, 5)
    plt.imshow(otsu_image6)
    plt.tight_layout()
    plt.savefig('otsu.svg', type='svg')
    plt.show()
    print('Threshold of every image in method of OTSU is:')
    print(otsu_threshold)
    ######################################################
    #in order to save time, I use best threshold of image come from OTSU, and input best threshold as fixed threshold
    #to get binary image
    binary_img1=Threshold(img1,188)
    binary_img3 = Threshold(img3, 120)
    binary_img4 = Threshold(img4, 119)
    binary_img5 = Threshold(img5, 208)
    binary_img6 = Threshold(img6, 114)
    thining_img1=Two_Step_Thining_Algorithm(binary_img1)
    thining_img3 = Two_Step_Thining_Algorithm(binary_img3)
    thining_img4 = Two_Step_Thining_Algorithm(binary_img4)
    thining_img5 = Two_Step_Thining_Algorithm(binary_img5)
    thining_img6 = Two_Step_Thining_Algorithm(binary_img6)
    plt.figure(figsize=(15, 5))
    plt.subplot(2,5,1)
    plt.imshow(binary_img1)
    plt.subplot(2, 5, 2)
    plt.imshow(binary_img3)
    plt.subplot(2, 5, 3)
    plt.imshow(binary_img4)
    plt.subplot(2, 5, 4)
    plt.imshow(binary_img5)
    plt.subplot(2, 5, 5)
    plt.imshow(binary_img6)
    plt.subplot(2, 5, 6)
    plt.imshow(thining_img1)
    plt.subplot(2, 5, 7)
    plt.imshow(thining_img3)
    plt.subplot(2, 5, 8)
    plt.imshow(thining_img4)
    plt.subplot(2, 5, 9)
    plt.imshow(thining_img5)
    plt.subplot(2, 5, 10)
    plt.imshow(thining_img6)
    plt.tight_layout()
    plt.savefig('two_setp_thining.svg', type='svg')
    plt.show()
    ##########################################################
    binary_img1 = Threshold(img1, 188)
    binary_img3 = Threshold(img3, 120)
    binary_img4 = Threshold(img4, 119)
    binary_img5 = Threshold(img5, 208)
    binary_img6 = Threshold(img6, 114)
    axis_img1 = Medial_Axis_Transformation(binary_img1)
    axis_img3 = Medial_Axis_Transformation(binary_img3)
    axis_img4 = Medial_Axis_Transformation(binary_img4)
    axis_img5 = Medial_Axis_Transformation(binary_img5)
    axis_img6 = Medial_Axis_Transformation(binary_img6)
    plt.figure(figsize=(15, 5))
    plt.subplot(2, 5, 1)
    plt.imshow(binary_img1)
    plt.subplot(2, 5, 2)
    plt.imshow(binary_img3)
    plt.subplot(2, 5, 3)
    plt.imshow(binary_img4)
    plt.subplot(2, 5, 4)
    plt.imshow(binary_img5)
    plt.subplot(2, 5, 5)
    plt.imshow(binary_img6)
    plt.subplot(2, 5, 6)
    plt.imshow(axis_img1)
    plt.subplot(2, 5, 7)
    plt.imshow(axis_img3)
    plt.subplot(2, 5, 8)
    plt.imshow(axis_img4)
    plt.subplot(2, 5, 9)
    plt.imshow(axis_img5)
    plt.subplot(2, 5, 10)
    plt.imshow(axis_img6)
    plt.tight_layout()
    plt.savefig('axis.svg', type='svg')
    plt.show()
main_function(img1,img3,img4,img5,img6,5,200)






